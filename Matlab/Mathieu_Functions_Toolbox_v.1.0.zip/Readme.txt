Changes performed by revision, November 2008:

-notations 'eta' and 'veta' are replaced by 't' and 'vt', respectively;
-notation of expansion coefficients Boe and Boo is changed to Aoe and Aoo, respectively;
-the option "nobalance" is added in the routine 'eig_Spm';
-the minus sign is taken off at odd radial functions: Joe, Joo, Yoe, and Yoo; also at their derivatives;
-the minus sign is added in Eq.(27) of the revised documentation;
-the routines 'extract_one_value' and 'extract_one_column' are added;
-tables II-VI providing numerical values are added;
-a more clear distinction is done between the radial Mathieu function of the first kind, Jpm(u,q,n) and 
 the 'modified' Mathieu function, Spm(iu,q,n). I aknowledge the suggestions and the kind help accorded by
 Prof. D. A. Pujara, Nirma University, India.